## 1.1.2 (2024-08-26)

- No documented changes


## 1.1.1 (2024-08-20)

### Fixes

- random change
- gitversion change
- random change
- random change
- updated changelog with initial version
- updated gitversion config


## 1.1.0 (2024-08-13)

### Improvements

- Initial version